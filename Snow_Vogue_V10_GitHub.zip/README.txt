GitHub Pages 배포: 새 public 저장소 생성 → index.html 업로드 → Settings → Pages → Deploy from a branch → main / (root) → Save. 여러 기기 연결은 아래 기존 Firebase 설정 참고.

SNOW VOGUE — 겨울 패션 페스티벌

1. index.html을 브라우저에서 열면 혼자 연습하기가 가능합니다.
2. GitHub에서 새 공개 저장소를 만들고 index.html을 루트에 업로드합니다.
3. Settings > Pages > Deploy from a branch > main / root를 선택하여 저장합니다.
4. 생성된 HTTPS 주소를 친구들에게 공유합니다.
5. 여러 기기 연결: Firebase 전용 테스트 프로젝트를 만들고 웹 앱을 추가합니다. Authentication에서 익명 로그인을 활성화하고 Realtime Database를 생성합니다. 아래 firebase-rules.json의 규칙을 게시합니다. 웹 앱 설정의 firebaseConfig JSON에 databaseURL을 포함하여 게임의 기기 연결 설정에 저장합니다. 연결 주소 복사 기능으로 참가자에게 같은 설정 주소를 공유합니다.
6. 교사는 새 방을 만들고 4자리 번호를 공유합니다. 학생들은 이름과 번호를 입력합니다. 교사가 미션을 시작하면 동일한 종료 시각이 공유됩니다. 런웨이는 교사 진행판에서 시작/다음 모델/시상식으로 진행합니다.

주의: 이 프로토타입은 신뢰하는 교실 참가자용입니다. 인증된 사용자가 방 데이터를 수정할 수 있으므로 공개 대회에는 부적합합니다. 전용 프로젝트를 사용하고 수업 후 데이터를 삭제하세요. 실제 Firebase 기기 간 연동은 설정 후 시험해야 합니다. 기본 모드는 같은 브라우저의 여러 탭에서만 공유됩니다. 2D SVG 캐릭터입니다.

3D 버전: index.html과 scene.js를 같은 폴더에 배포하세요. Three.js CDN 및 WebGL 지원 브라우저가 필요합니다. 로컬 파일 직접 열기 대신 GitHub Pages 또는 로컬 HTTP 서버로 실행하세요. 캐릭터를 좌우 드래그하면 회전합니다.
